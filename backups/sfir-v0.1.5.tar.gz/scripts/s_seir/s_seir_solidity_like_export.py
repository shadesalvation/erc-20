#!/usr/bin/env python3
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import re
from typing import Any

from s_seir_model import EffectNode, FunctionSSEIR, SemanticOverlay, SourceStatement
from s_seir_yul_normalize import normalize_expr


def write_solidity_like_text(functions: list[FunctionSSEIR], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_solidity_like_text(functions), encoding="utf-8")


def render_solidity_like_text(functions: list[FunctionSSEIR]) -> str:
    lines: list[str] = [
        "S-SEIR Solidity-like Assembly View",
        "Note: derived view only; source is not modified and output is not compiled.",
        "",
    ]
    for fn in functions:
        if not any(stmt.lang == "yul" for stmt in fn.source_statements):
            continue
        renderer = SolidityLikeRenderer(fn)
        lines.extend(renderer.render_function())
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


class SolidityLikeRenderer:
    """Render a source-ordered Solidity-like view from S-SEIR overlays/effects.

    This is intentionally a projection of the S-SEIR graph, not a second
    analysis pipeline. Statement selection follows the legacy recovery priority:
    require/event/call/storage overlays first, expression normalization next,
    memory effects next, and raw Yul as the final fallback.
    """

    def __init__(self, fn: FunctionSSEIR):
        self.fn = fn
        self.stmt_by_id = {stmt.stmt_id: stmt for stmt in fn.source_statements}
        self.effects_by_ref = self._effects_by_ref(fn.effects)
        self.effect_by_id = {effect.effect_id: effect for effect in fn.effects}
        self.overlays_by_ref = self._overlays_by_anchor(fn.semantic_overlays)
        self.condition_aliases = self._condition_aliases(fn.effects)
        self.skip_branch_conditions = self._skip_branch_conditions(fn.semantic_overlays)
        self.memory_construction_notes = self._memory_construction_notes(fn.semantic_overlays)
        self.struct_field_lines_by_effect = self._struct_field_lines_by_effect(fn.semantic_overlays)
        self.loop_groups = self._loop_groups()
        self.loop_exit_suppressions_by_stmt = self._loop_exit_suppressions_by_stmt()
        self._condition_fingerprint_cache: dict[str, set[str]] = {}
        self._condition_equivalence_cache: dict[tuple[str, str], bool] = {}

    def render_function(self) -> list[str]:
        lines = [f"Function {self.fn.contract}.{self.fn.signature}"]
        source_text = self.function_source_text()
        if source_text:
            lines.append("  SourceFunction")
            lines.append("  ```solidity")
            for line in source_text.rstrip().splitlines():
                lines.append(f"  {line}")
            lines.append("  ```")
            solidity_like = self.function_solidity_like_text(source_text)
            if solidity_like:
                lines.append("  SolidityLikeFunction")
                lines.append("  ```solidity")
                for line in solidity_like.rstrip().splitlines():
                    lines.append(f"  {line}")
                lines.append("  ```")
                return lines
        lines.extend(self.render_assembly_blocks())
        return lines

    def render_assembly_blocks(self) -> list[str]:
        lines: list[str] = []
        block_ids = []
        for stmt in self.fn.source_statements:
            if stmt.lang == "yul" and stmt.block_id and stmt.block_id not in block_ids:
                block_ids.append(stmt.block_id)
        for block_id in block_ids:
            lines.append(f"  AssemblyBlock {block_id}")
            lines.append("  ```solidity")
            lines.append("  assembly /* s-seir solidity-like view */ {")
            for line in self.render_assembly_block_body(block_id):
                lines.append(f"      {line}")
            lines.append("  }")
            lines.append("  ```")
        return lines

    def render_assembly_block_body(
        self,
        block_id: str,
        suppress_predicates: list[str] | None = None,
    ) -> list[str]:
        yul_stmts = [s for s in self.fn.source_statements if s.lang == "yul" and s.block_id == block_id]
        if not yul_stmts:
            return []
        consumed: set[str] = set()
        body_lines: list[str] = list(self.memory_construction_notes)
        for stmt in yul_stmts:
            if stmt.stmt_id in consumed:
                continue
            loop_group = self.loop_groups.get(stmt.stmt_id)
            if loop_group:
                rendered = self.render_loop_group(
                    loop_group,
                    yul_stmts,
                    suppress_predicates=suppress_predicates,
                )
                consumed.update(loop_group["consumed_stmt_ids"])
                body_lines.extend(rendered)
                continue
            rendered = self.render_stmt(stmt, suppress_predicates=suppress_predicates)
            if rendered is None:
                continue
            comment_index = self.comment_line_index(rendered)
            for index, line in enumerate(rendered):
                comment = f" // yul: {stmt.text}" if index == comment_index else ""
                body_lines.append(f"{line}{comment}")
        return self.optimize_condition_blocks(body_lines)

    def function_solidity_like_text(self, source_text: str) -> str | None:
        block_ids = []
        for stmt in self.fn.source_statements:
            if stmt.lang == "yul" and stmt.block_id and stmt.block_id not in block_ids:
                block_ids.append(stmt.block_id)
        if not block_ids:
            return None
        ranges = self.find_assembly_ranges(source_text)
        if not ranges:
            return None
        result = source_text
        replacements: list[tuple[int, int, str]] = []
        for block_id, (start, end) in zip(block_ids, ranges):
            indent = self.line_indent(source_text, start)
            replacement_lines = ["assembly /* s-seir solidity-like view */ {"]
            boundary_predicates = self.assembly_boundary_predicates(block_id)
            replacement_lines.extend(
                f"{indent}    {line}"
                for line in self.render_assembly_block_body(
                    block_id,
                    suppress_predicates=boundary_predicates,
                )
            )
            replacement_lines.append(f"{indent}}}")
            replacements.append((start, end, "\n".join(replacement_lines)))
        for start, end, replacement in reversed(replacements):
            result = result[:start] + replacement + result[end:]
        result = self.annotate_return_expressions(result)
        return self.format_solidity_like_source(result)

    def assembly_boundary_predicates(self, block_id: str) -> list[str]:
        """Find Solidity predicates already visible around this assembly block."""

        boundaries = (self.fn.control or {}).get("assembly_boundaries") or {}
        suffix = re.search(r"(\d+)$", str(block_id or ""))
        keys: list[Any] = [block_id]
        if suffix:
            keys.extend([suffix.group(1), int(suffix.group(1))])
        boundary = next((boundaries.get(key) for key in keys if boundaries.get(key)), None)
        if not isinstance(boundary, dict):
            return []
        predicates: list[str] = []
        for dependency in boundary.get("control_dependencies") or []:
            predicate = str(dependency.get("predicate") or "").strip()
            if predicate and predicate not in predicates:
                predicates.append(predicate)
        return predicates

    @staticmethod
    def format_solidity_like_source(source_text: str) -> str:
        """Indent the derived function view without changing source semantics.

        Some verified contracts are flattened or minified with every line at
        column zero. The Solidity-like view is an audit artifact, so it can use
        brace-based indentation even when the original source did not.
        """

        lines: list[str] = []
        depth = 0
        for raw in source_text.strip("\n").splitlines():
            stripped = raw.strip()
            if not stripped:
                lines.append("")
                continue
            leading_closes = len(stripped) - len(stripped.lstrip("}"))
            if leading_closes:
                depth = max(depth - leading_closes, 0)
            lines.append(f"{'    ' * depth}{stripped}")
            opens = stripped.count("{")
            closes = stripped.count("}")
            depth = max(depth + opens - max(closes - leading_closes, 0), 0)
        return "\n".join(lines)

    def annotate_return_expressions(self, source_text: str) -> str:
        replacements = self.semantic_assignment_replacements()
        if not replacements:
            return source_text

        def repl(match: re.Match[str]) -> str:
            expr = match.group(1).strip()
            notes = self.return_semantic_notes(expr, replacements)
            if not notes:
                return match.group(0)
            return f"return {expr}; /* s-seir: {', '.join(notes)} */"

        return re.sub(r"\breturn\s+([^;{}]+);", repl, source_text)

    def semantic_assignment_replacements(self) -> dict[str, str]:
        candidates: dict[str, set[str]] = defaultdict(set)
        for overlay in self.fn.semantic_overlays:
            attrs = overlay.attrs
            target = attrs.get("target")
            if not self.simple_identifier(target):
                continue
            if attrs.get("path_states"):
                continue
            expr = None
            if overlay.kind == "AddressCodeSize":
                expr = attrs.get("code_size")
            elif overlay.kind == "AddressHasCode":
                expr = attrs.get("condition")
            elif overlay.kind == "ExpressionNormalization" and attrs.get("context") == "value":
                expr = attrs.get("expression_normalized")
            if not expr:
                continue
            normalized = normalize_expr(expr)
            if normalized and normalized != str(target):
                candidates[str(target)].add(normalized)
        return {target: next(iter(exprs)) for target, exprs in candidates.items() if len(exprs) == 1}

    @staticmethod
    def simple_identifier(value: Any) -> bool:
        text = str(value or "").strip()
        return bool(re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", text))

    @classmethod
    def replace_identifiers(cls, expr: str, replacements: dict[str, str]) -> str:
        out = expr
        for name, value in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
            if name in value:
                continue
            out = re.sub(rf"\b{re.escape(name)}\b", f"({value})", out)
        return out

    @staticmethod
    def return_semantic_notes(expr: str, replacements: dict[str, str]) -> list[str]:
        notes: list[str] = []
        for name, value in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
            if re.search(rf"\b{re.escape(name)}\b", expr):
                notes.append(f"{name} == {value}")
        return notes

    @staticmethod
    def line_indent(text: str, index: int) -> str:
        line_start = text.rfind("\n", 0, index) + 1
        match = re.match(r"[ \t]*", text[line_start:index])
        return match.group(0) if match else ""

    @classmethod
    def find_assembly_ranges(cls, source_text: str) -> list[tuple[int, int]]:
        ranges: list[tuple[int, int]] = []
        index = 0
        while index < len(source_text):
            match = re.search(r"\bassembly\b", source_text[index:])
            if not match:
                break
            start = index + match.start()
            if not cls.in_code_context(source_text, start):
                index = start + len("assembly")
                continue
            brace = source_text.find("{", start)
            if brace < 0:
                break
            end = cls.matching_brace_end(source_text, brace)
            if end is None:
                break
            ranges.append((start, end))
            index = end
        return ranges

    @staticmethod
    def in_code_context(source_text: str, index: int) -> bool:
        state = "code"
        i = 0
        while i < index:
            ch = source_text[i]
            nxt = source_text[i + 1] if i + 1 < len(source_text) else ""
            if state == "code":
                if ch == "/" and nxt == "/":
                    state = "line_comment"
                    i += 2
                    continue
                if ch == "/" and nxt == "*":
                    state = "block_comment"
                    i += 2
                    continue
                if ch in {'"', "'"}:
                    state = f"string_{ch}"
            elif state == "line_comment":
                if ch == "\n":
                    state = "code"
            elif state == "block_comment":
                if ch == "*" and nxt == "/":
                    state = "code"
                    i += 2
                    continue
            elif state.startswith("string_"):
                quote = state[-1]
                if ch == "\\":
                    i += 2
                    continue
                if ch == quote:
                    state = "code"
            i += 1
        return state == "code"

    @staticmethod
    def matching_brace_end(source_text: str, brace_index: int) -> int | None:
        depth = 0
        state = "code"
        i = brace_index
        while i < len(source_text):
            ch = source_text[i]
            nxt = source_text[i + 1] if i + 1 < len(source_text) else ""
            if state == "code":
                if ch == "/" and nxt == "/":
                    state = "line_comment"
                    i += 2
                    continue
                if ch == "/" and nxt == "*":
                    state = "block_comment"
                    i += 2
                    continue
                if ch in {'"', "'"}:
                    state = f"string_{ch}"
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        return i + 1
            elif state == "line_comment":
                if ch == "\n":
                    state = "code"
            elif state == "block_comment":
                if ch == "*" and nxt == "/":
                    state = "code"
                    i += 2
                    continue
            elif state.startswith("string_"):
                quote = state[-1]
                if ch == "\\":
                    i += 2
                    continue
                if ch == quote:
                    state = "code"
            i += 1
        return None

    def function_source_text(self) -> str | None:
        source = getattr(self.fn, "_sseir_function_source", None)
        if not isinstance(source, dict):
            return None
        text = str(source.get("text") or "").strip("\n")
        return text or None

    def render_loop_group(
        self,
        loop_group: dict[str, Any],
        yul_stmts: list[SourceStatement],
        suppress_predicates: list[str] | None = None,
    ) -> list[str]:
        lines: list[str] = []
        stmt_by_id = {stmt.stmt_id: stmt for stmt in yul_stmts}
        outer_suppress = list(suppress_predicates or [])
        suppress = [*outer_suppress, loop_group["condition"]]

        for stmt_id in loop_group["pre_stmt_ids"]:
            stmt = stmt_by_id.get(stmt_id)
            if not stmt:
                continue
            rendered = self.render_stmt(stmt, suppress_predicates=outer_suppress)
            if not rendered:
                continue
            lines.extend(self.attach_yul_comments(rendered, stmt))

        post_clause = self.loop_post_clause(loop_group, yul_stmts)
        normalized_condition = normalize_expr(loop_group['condition'], context='condition')
        if post_clause is not None:
            if not post_clause and self.is_static_true_condition(loop_group['condition']):
                lines.append("while (true) { // yul: for")
            else:
                lines.append(f"for (; {normalized_condition}; {post_clause}) {{ // yul: for")
        else:
            if self.is_static_true_condition(loop_group['condition']):
                lines.append("while (true) { // yul: for")
            else:
                lines.append(f"while ({normalized_condition}) {{ // yul: for")
        body_lines: list[str] = []
        for stmt_id in loop_group["body_stmt_ids"]:
            stmt = stmt_by_id.get(stmt_id)
            if not stmt:
                continue
            rendered = self.render_stmt(stmt, suppress_predicates=suppress)
            if not rendered:
                continue
            for line in self.attach_yul_comments(rendered, stmt):
                body_lines.append(f"    {line}")
        lines.extend(self.optimize_condition_blocks(body_lines))
        lines.append("}")
        return lines

    def loop_post_clause(self, loop_group: dict[str, Any], yul_stmts: list[SourceStatement]) -> str | None:
        stmt_by_id = {stmt.stmt_id: stmt for stmt in yul_stmts}
        clauses: list[str] = []
        for stmt_id in loop_group.get("post_stmt_ids") or []:
            stmt = stmt_by_id.get(stmt_id)
            if not stmt:
                continue
            line = self.render_stmt_unconditioned(stmt)
            if not line:
                return None
            clauses.append(line.rstrip(";"))
        return "; ".join(clauses) if clauses else ""

    @staticmethod
    def is_static_true_condition(condition: Any) -> bool:
        text = str(condition or "").strip().lower()
        if text == "true":
            return True
        try:
            return int(text, 0) != 0
        except Exception:
            return False

    def render_stmt_unconditioned(self, stmt: SourceStatement) -> str | None:
        overlays = self.overlays_by_ref.get(stmt.stmt_id, [])
        overlay_lines = self.overlay_lines(overlays)
        if overlay_lines:
            return "\n".join(overlay_lines)
        expression = self.expression_normalization(overlays)
        if expression:
            return expression
        memory = self.memory_write_line(stmt)
        if memory:
            return memory
        if self.branch_effect(stmt) is not None or self.is_control_scaffold(stmt):
            return None
        return self.raw_statement_line(stmt)

    def attach_yul_comments(self, rendered: list[str], stmt: SourceStatement) -> list[str]:
        out: list[str] = []
        comment_index = self.comment_line_index(rendered)
        for index, line in enumerate(rendered):
            comment = f" // yul: {stmt.text}" if index == comment_index else ""
            out.append(f"{line}{comment}")
        return out

    def render_stmt(self, stmt: SourceStatement, suppress_predicates: list[str] | None = None) -> list[str] | None:
        overlays = self.overlays_by_ref.get(stmt.stmt_id, [])
        if any(o.kind == "RequireOverlay" and o.attrs.get("elided_by_native_precompile") for o in overlays):
            return None
        evaluation_lines = self.evaluation_step_lines(overlays)
        if evaluation_lines:
            value_expression = self.value_expression_normalization(overlays)
            if value_expression and value_expression not in evaluation_lines:
                evaluation_lines = [*evaluation_lines, value_expression]
            return self.with_path_condition(stmt, overlays, evaluation_lines, suppress_predicates=suppress_predicates)
        overlay_lines = self.overlay_lines(overlays)
        if overlay_lines:
            return self.with_path_condition(stmt, overlays, overlay_lines, suppress_predicates=suppress_predicates)

        branch = self.branch_effect(stmt)
        if branch is not None:
            return None

        expression = self.expression_normalization(overlays)
        if expression:
            return self.with_path_condition(stmt, overlays, [expression], suppress_predicates=suppress_predicates)

        memory = self.memory_write_line(stmt)
        if memory:
            return self.with_path_condition(stmt, overlays, [memory], suppress_predicates=suppress_predicates)

        if self.is_control_scaffold(stmt):
            return None
        return self.with_path_condition(stmt, overlays, [self.raw_statement_line(stmt)], suppress_predicates=suppress_predicates)

    @staticmethod
    def comment_line_index(lines: list[str]) -> int:
        for index, line in enumerate(lines):
            stripped = line.strip()
            if stripped and stripped not in {"{", "}"} and not stripped.startswith("if "):
                return index
        return 0

    def with_path_condition(self, stmt: SourceStatement, overlays: list[SemanticOverlay], lines: list[str], suppress_predicates: list[str] | None = None) -> list[str]:
        suppress_predicates = list(suppress_predicates or [])
        for overlay in overlays:
            if overlay.kind != "RequireOverlay":
                continue
            attrs = overlay.attrs
            nearest = attrs.get("nearest_condition")
            if nearest:
                suppress_predicates.append(str(nearest))
            for condition in attrs.get("require_conditions") or []:
                if condition:
                    suppress_predicates.append(str(condition))
        for predicate in suppress_predicates:
            lines = self.remove_redundant_inner_condition(lines, predicate)
        condition = self.statement_condition(stmt, overlays, suppress_predicates=suppress_predicates)
        if not condition:
            return lines
        lines = self.remove_redundant_inner_condition(lines, condition)
        tree_lines = self.condition_tree_block(condition, lines)
        if tree_lines:
            return tree_lines
        out = [f"if ({condition}) {{"]
        out.extend(f"    {line}" for line in lines)
        out.append("}")
        return out

    @classmethod
    def condition_tree_block(cls, condition: str, lines: list[str]) -> list[str]:
        """Render a long DNF condition as nested condition scopes.

        This is only a Solidity-like presentation optimization. The S-SEIR
        path state remains unchanged; the renderer simply expands a large
        `if ((a && b) || (a && c))` into a condition tree with shared parents.
        """

        if "||" not in str(condition):
            return []
        terms = cls.parse_condition_dnf(condition)
        if not terms:
            return []
        if len(terms) == 1:
            term = terms[0]
            if not term:
                return lines
            simplified = cls.condition_term_text(term)
            out = [f"if ({simplified}) {{"]
            out.extend(f"    {line}" for line in lines)
            out.append("}")
            return out
        return cls.render_condition_terms(terms, lines, 0)

    @classmethod
    def parse_condition_dnf(cls, condition: str) -> list[frozenset[str]]:
        text = cls.strip_outer_parens(str(condition or "").strip())
        if not text or text == "entry":
            return [frozenset()]
        terms: list[frozenset[str]] = []
        for disjunct in cls.split_top_level(text, "||"):
            atoms = [
                cls.normalize_condition_atom(part)
                for part in cls.split_top_level(cls.strip_outer_parens(disjunct), "&&")
            ]
            terms.append(frozenset(atom for atom in atoms if atom))
        return cls.simplify_condition_terms(terms)

    @classmethod
    def simplify_condition_terms(cls, terms: list[frozenset[str]]) -> list[frozenset[str]]:
        cleaned: set[frozenset[str]] = set()
        for term in terms:
            atoms = set(term)
            if any(cls.negated_condition_atom(atom) in atoms for atom in atoms):
                continue
            cleaned.add(frozenset(atoms))

        absorbed = set(cleaned)
        for left in cleaned:
            for right in cleaned:
                if left != right and left.issubset(right):
                    absorbed.discard(right)

        return sorted(absorbed, key=lambda item: (len(item), sorted(item)))

    @classmethod
    def render_condition_terms(cls, terms: list[frozenset[str]], lines: list[str], indent: int) -> list[str]:
        out: list[str] = []
        current = [term for term in terms if not term]
        remaining = [term for term in terms if term]
        for _term in current:
            out.extend(f"{'    ' * indent}{line}" for line in lines)

        while remaining:
            atom = cls.choose_condition_tree_atom(remaining)
            if atom is None:
                for term in sorted(remaining, key=lambda item: (len(item), sorted(item))):
                    condition = cls.condition_term_text(term)
                    out.append(f"{'    ' * indent}if ({condition}) {{")
                    out.extend(f"{'    ' * (indent + 1)}{line}" for line in lines)
                    out.append(f"{'    ' * indent}}}")
                break

            grouped = [term for term in remaining if atom in term]
            remaining = [term for term in remaining if atom not in term]
            child_terms = [frozenset(set(term) - {atom}) for term in grouped]
            out.append(f"{'    ' * indent}if ({atom}) {{")
            out.extend(cls.render_condition_terms(child_terms, lines, indent + 1))
            out.append(f"{'    ' * indent}}}")
        return out

    @classmethod
    def choose_condition_tree_atom(cls, terms: list[frozenset[str]]) -> str | None:
        counts: dict[str, int] = {}
        for term in terms:
            for atom in term:
                counts[atom] = counts.get(atom, 0) + 1
        if not counts:
            return None
        atom, count = max(counts.items(), key=lambda item: (item[1], -cls.condition_atom_sort_key(item[0])[0], item[0]))
        return atom if count > 1 else None

    @staticmethod
    def condition_atom_sort_key(atom: str) -> tuple[int, str]:
        return (atom.count("__sseir_eval"), atom)

    @classmethod
    def condition_term_text(cls, term: frozenset[str]) -> str:
        atoms = sorted(term, key=cls.condition_atom_sort_key)
        return " && ".join(atoms) if atoms else "true"

    @classmethod
    def strip_outer_parens(cls, text: str) -> str:
        value = str(text or "").strip()
        while value.startswith("(") and value.endswith(")") and cls.parens_enclose_all(value):
            value = value[1:-1].strip()
        return value

    @staticmethod
    def parens_enclose_all(text: str) -> bool:
        depth = 0
        for index, ch in enumerate(text):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and index != len(text) - 1:
                    return False
                if depth < 0:
                    return False
        return depth == 0

    @classmethod
    def split_top_level(cls, text: str, op: str) -> list[str]:
        parts: list[str] = []
        start = 0
        depth = 0
        index = 0
        while index < len(text):
            ch = text[index]
            if ch == "(":
                depth += 1
                index += 1
                continue
            if ch == ")":
                depth -= 1
                index += 1
                continue
            if depth == 0 and text.startswith(op, index):
                parts.append(text[start:index].strip())
                index += len(op)
                start = index
                continue
            index += 1
        parts.append(text[start:].strip())
        return [part for part in parts if part]

    @classmethod
    def normalize_condition_atom(cls, text: str) -> str:
        value = cls.strip_outer_parens(text)
        if value.startswith("!(") and value.endswith(")") and cls.parens_enclose_all(value[1:]):
            return f"!({cls.normalize_condition_atom(value[2:-1])})"
        return value

    @classmethod
    def negated_condition_atom(cls, atom: str) -> str:
        value = str(atom or "").strip()
        if value.startswith("!(") and value.endswith(")") and cls.parens_enclose_all(value[1:]):
            return cls.normalize_condition_atom(value[2:-1])
        return f"!({value})"

    def remove_redundant_inner_condition(self, lines: list[str], outer_condition: str) -> list[str]:
        """Drop a nested `if` whose guard is already guaranteed by the caller.

        Path-conditioned overlays can carry the same path predicate that the
        source-ordered statement renderer has already materialized around the
        statement. This presentation-only cleanup removes that duplicate scope
        while keeping non-equivalent candidate conditions intact.
        """

        parsed = self.parse_if_block(lines, 0)
        if parsed is None:
            return lines
        opener, inner, closer, end_index = parsed
        if end_index != len(lines) - 1 or closer.strip() != "}":
            return lines
        condition = self.if_opener_condition(opener)
        if not condition:
            return lines
        if self.conditions_equivalent(condition, outer_condition):
            return [line[4:] if line.startswith("    ") else line for line in inner]

        parts = self.split_top_level(self.strip_outer_parens(condition), "&&")
        if len(parts) <= 1:
            return lines
        remaining = [
            part
            for part in parts
            if not self.is_suppressed_predicate(part, [outer_condition])
            and not self.conditions_equivalent(part, outer_condition)
        ]
        if len(remaining) == len(parts):
            return lines
        if not remaining:
            return [line[4:] if line.startswith("    ") else line for line in inner]
        indent = opener[: len(opener) - len(opener.lstrip())]
        reduced = " && ".join(remaining)
        return [f"{indent}if ({reduced}) {{", *inner, closer]

    @staticmethod
    def if_opener_condition(opener: str) -> str | None:
        match = re.match(r"^\s*if \((.+)\) \{$", opener)
        return match.group(1).strip() if match else None

    def conditions_equivalent(self, left: str, right: str) -> bool:
        left_text = self.strip_outer_parens(str(left or "").strip())
        right_text = self.strip_outer_parens(str(right or "").strip())
        key = tuple(sorted((left_text, right_text)))
        if key in self._condition_equivalence_cache:
            return self._condition_equivalence_cache[key]
        if left_text == right_text:
            self._condition_equivalence_cache[key] = True
            return True
        if self.long_condition(left) or self.long_condition(right):
            self._condition_equivalence_cache[key] = False
            return False
        result = self.conditions_equivalent_cheap(left_text, right_text)
        self._condition_equivalence_cache[key] = result
        return result

    def conditions_equivalent_cheap(self, left: str, right: str) -> bool:
        pairs = {
            (left, right),
            (self.strip_outer_parens(left), self.strip_outer_parens(right)),
        }
        for a, b in list(pairs):
            if a == b:
                return True
            normalized_a = self.strip_outer_parens(normalize_expr(a, context="condition"))
            normalized_b = self.strip_outer_parens(normalize_expr(b, context="condition"))
            if normalized_a == normalized_b:
                return True
            if self.condition_aliases.get(a) == b or self.condition_aliases.get(b) == a:
                return True
            if self.negated_alias(a) == b or self.negated_alias(b) == a:
                return True
            if self.simple_comparison_key(a) and self.simple_comparison_key(a) == self.simple_comparison_key(b):
                return True
        return False

    def negated_alias(self, condition: str) -> str | None:
        text = str(condition or "").strip()
        if not (text.startswith("!(") and text.endswith(")")):
            return None
        inner = self.strip_outer_parens(text[2:-1].strip())
        alias = self.condition_aliases.get(inner)
        return f"!({alias})" if alias else None

    @staticmethod
    def long_condition(condition: Any) -> bool:
        text = str(condition or "")
        return len(text) > 512 or text.count("&&") + text.count("||") > 16

    def condition_fingerprints(self, condition: str) -> set[str]:
        cache_key = str(condition or "").strip()
        cached = self._condition_fingerprint_cache.get(cache_key)
        if cached is not None:
            return cached
        out: set[str] = set()
        stack = [cache_key]
        inverse_aliases = {value: key for key, value in self.condition_aliases.items()}
        while stack:
            text = self.strip_outer_parens(stack.pop().strip())
            if not text:
                continue
            out.add(text)
            out.add(self.strip_outer_parens(text))
            out.update(self.simple_condition_variants(text))
            if text.startswith("!(") and text.endswith(")"):
                inner = text[2:-1].strip()
                out.add(f"!({self.strip_outer_parens(inner)})")
                for variant in self.simple_condition_variants(inner):
                    out.add(f"!({variant})")
                if inner in inverse_aliases:
                    stack.append(f"!({inverse_aliases[inner]})")
                continue
            if text in self.condition_aliases:
                stack.append(self.condition_aliases[text])
            if text in inverse_aliases:
                stack.append(inverse_aliases[text])
        self._condition_fingerprint_cache[cache_key] = out
        return out

    @classmethod
    def simple_condition_variants(cls, condition: Any) -> set[str]:
        key = cls.simple_comparison_key(condition)
        if not key:
            return set()
        op, left, right = key
        infix_op = {"eq": "==", "ne": "!=", "lt": "<", "gt": ">", "le": "<=", "ge": ">="}[op]
        return {
            f"{op}({left}, {right})",
            f"{op}({left},{right})",
            f"{left} {infix_op} {right}",
            f"({left} {infix_op} {right})",
        }

    @classmethod
    def simple_comparison_key(cls, condition: Any) -> tuple[str, str, str] | None:
        text = cls.strip_outer_parens(str(condition or "").strip())
        call = cls.parse_simple_yul_comparison(text)
        if call:
            return call
        return cls.parse_simple_infix_comparison(text)

    @staticmethod
    def parse_simple_yul_comparison(text: str) -> tuple[str, str, str] | None:
        for op in ("eq", "ne", "lt", "gt", "le", "ge"):
            prefix = f"{op}("
            if not text.startswith(prefix) or not text.endswith(")"):
                continue
            inner = text[len(prefix):-1]
            if inner.count(",") != 1:
                return None
            left, right = (part.strip() for part in inner.split(",", 1))
            if left and right:
                return op, left, right
        return None

    @staticmethod
    def parse_simple_infix_comparison(text: str) -> tuple[str, str, str] | None:
        for symbol, op in (("==", "eq"), ("!=", "ne"), ("<=", "le"), (">=", "ge"), ("<", "lt"), (">", "gt")):
            if symbol not in text:
                continue
            left, right = (part.strip() for part in text.split(symbol, 1))
            if left and right and all(sep not in left + right for sep in ("&&", "||", "(", ")", ",")):
                return op, left, right
        return None

    @classmethod
    def coalesce_adjacent_condition_blocks(cls, lines: list[str]) -> list[str]:
        """Merge adjacent `if (same_condition)` blocks in the rendered view.

        This is a presentation-only pass. It preserves statement order and only
        merges blocks when their opening line is textually identical, including
        indentation, so nested scopes and different path conditions stay
        separate.
        """

        out: list[str] = []
        index = 0
        while index < len(lines):
            current = cls.parse_if_block(lines, index)
            if current is None:
                out.append(lines[index])
                index += 1
                continue

            opener, inner, closer, end_index = current
            index = end_index + 1
            while index < len(lines):
                next_block = cls.parse_if_block(lines, index)
                if next_block is None or next_block[0] != opener:
                    break
                inner.extend(next_block[1])
                index = next_block[3] + 1

            out.append(opener)
            out.extend(inner)
            out.append(closer)
        return out

    @classmethod
    def optimize_condition_blocks(cls, lines: list[str]) -> list[str]:
        """Presentation-only condition compaction for rendered lines.

        The S-SEIR graph remains unchanged. This pass only rewrites adjacent
        rendered `if` blocks when their body text is identical, or when their
        opener is textually identical. That keeps the optimization conservative:
        distinct semantic statements are never merged.
        """

        previous: list[str] | None = None
        current = list(lines)
        for _ in range(4):
            current = cls.coalesce_duplicate_single_line_if_blocks(current)
            current = cls.coalesce_adjacent_condition_blocks(current)
            if current == previous:
                break
            previous = list(current)
        return current

    @classmethod
    def coalesce_duplicate_single_line_if_blocks(cls, lines: list[str]) -> list[str]:
        out: list[str] = []
        index = 0
        while index < len(lines):
            parsed = cls.parse_if_block(lines, index)
            if parsed is None:
                out.append(lines[index])
                index += 1
                continue

            opener, inner, closer, end_index = parsed
            optimized_inner = cls.optimize_condition_blocks([line[4:] if line.startswith("    ") else line for line in inner])
            normalized_inner = [f"    {line}" for line in optimized_inner]
            condition = cls.if_opener_condition(opener)
            if not condition or len(optimized_inner) != 1 or optimized_inner[0].lstrip().startswith("if "):
                out.append(opener)
                out.extend(normalized_inner)
                out.append(closer)
                index = end_index + 1
                continue

            body_line = optimized_inner[0]
            body_key = cls.rendered_line_semantic_key(body_line)
            conditions = [condition]
            index = end_index + 1
            while index < len(lines):
                next_block = cls.parse_if_block(lines, index)
                if next_block is None:
                    break
                next_opener, next_inner, _next_closer, next_end = next_block
                next_optimized = cls.optimize_condition_blocks([line[4:] if line.startswith("    ") else line for line in next_inner])
                next_condition = cls.if_opener_condition(next_opener)
                if not next_condition or len(next_optimized) != 1 or cls.rendered_line_semantic_key(next_optimized[0]) != body_key:
                    break
                if " // yul:" not in body_line and " // yul:" in next_optimized[0]:
                    body_line = next_optimized[0]
                conditions.append(next_condition)
                index = next_end + 1

            if len(conditions) == 1:
                out.append(opener)
                out.append(f"    {body_line}")
                out.append(closer)
                continue

            combined = cls.combined_condition_text(conditions)
            if not combined:
                out.append(body_line)
                continue
            out.append(f"if ({combined}) {{")
            out.append(f"    {body_line}")
            out.append("}")
        return out

    @classmethod
    def combined_condition_text(cls, conditions: list[str]) -> str | None:
        simplified = cls.simplify_disjunction([condition for condition in conditions if condition.strip()])
        if not simplified:
            return None
        if len(simplified) == 1:
            return normalize_expr(simplified[0], context="condition")
        return " || ".join(f"({normalize_expr(item, context='condition')})" for item in simplified)

    @staticmethod
    def rendered_line_semantic_key(line: str) -> str:
        return str(line or "").split(" // yul:", 1)[0].strip()

    @staticmethod
    def parse_if_block(lines: list[str], index: int) -> tuple[str, list[str], str, int] | None:
        if index >= len(lines):
            return None
        opener = lines[index]
        if not re.match(r"^\s*if \(.+\) \{$", opener):
            return None

        depth = 0
        for cursor in range(index, len(lines)):
            depth += lines[cursor].count("{")
            depth -= lines[cursor].count("}")
            if depth == 0:
                if cursor == index:
                    return None
                return opener, list(lines[index + 1 : cursor]), lines[cursor], cursor
        return None

    def statement_condition(self, stmt: SourceStatement, overlays: list[SemanticOverlay], suppress_predicates: list[str] | None = None) -> str | None:
        suppress_predicates = [
            *(suppress_predicates or []),
            *self.loop_exit_suppressions_by_stmt.get(stmt.stmt_id, []),
        ]
        states: list[str] = []
        for effect in self.effects_by_ref.get(stmt.stmt_id, []):
            for state in effect.attrs.get("path_states") or []:
                self.add_path_state(states, state)
        for overlay in overlays:
            for effect_id in overlay.effects:
                effect = self.effect_by_id.get(effect_id)
                if not effect:
                    continue
                for state in effect.attrs.get("path_states") or []:
                    self.add_path_state(states, state)
            for state in overlay.attrs.get("path_states") or []:
                self.add_path_state(states, state)
        if not states:
            return None
        states.sort(key=lambda item: len(self.path_parts(item)), reverse=True)
        if len(states) == 1:
            return self.normalize_path_state(states[0], suppress_predicates=suppress_predicates)
        normalized = [
            self.normalize_path_state(state, suppress_predicates=suppress_predicates)
            for state in states
        ]
        normalized = [item for item in normalized if item]
        if not normalized:
            return None
        normalized = self.simplify_disjunction(normalized)
        if not normalized:
            return None
        if len(normalized) == 1:
            return normalized[0]
        return " || ".join(f"({item})" for item in normalized)

    @staticmethod
    def add_path_state(states: list[str], state: Any) -> None:
        text = str(state or "").strip()
        if not text or text == "entry" or text in states:
            return
        states.append(text)

    @staticmethod
    def path_parts(state: str) -> list[str]:
        return [part.strip() for part in str(state).split(" && ") if part.strip()]

    def normalize_path_state(self, state: str, suppress_predicates: list[str] | None = None) -> str:
        parts = []
        for part in self.path_parts(state):
            if self.is_suppressed_predicate(part, suppress_predicates or []):
                continue
            parts.append(self.normalize_predicate(part))
        return " && ".join(parts)

    @staticmethod
    def is_suppressed_predicate(predicate: str, suppress_predicates: list[str]) -> bool:
        text = predicate.strip()
        normalized = normalize_expr(text[2:-1], context="condition") if text.startswith("!(") and text.endswith(")") else normalize_expr(text, context="condition")
        for item in suppress_predicates:
            raw = str(item).strip()
            if text == raw:
                return True
            if normalized == normalize_expr(raw, context="condition"):
                return True
        return False

    def normalize_predicate(self, predicate: str) -> str:
        text = predicate.strip()
        if text.startswith("!(") and text.endswith(")"):
            inner = text[2:-1].strip()
            alias = self.condition_aliases.get(inner)
            if alias:
                return f"!({alias})"
            return f"!({normalize_expr(inner, context='condition')})"
        alias = self.condition_aliases.get(text)
        if alias:
            return alias
        return normalize_expr(text, context="condition")

    @classmethod
    def simplify_disjunction(cls, terms: list[str]) -> list[str]:
        """Simplify path-state DNF produced by CFG path joins.

        Path states are rendered as conjunctions joined by ` && `. When all
        branches after an if join at the same statement, the raw DNF often
        contains both `cond` and `!(cond)`. Combining those complements keeps
        the source-like view from wrapping unconditional statements in a
        tautological guard.
        """

        term_sets = {frozenset(cls.split_conjunction(term)) for term in terms if term.strip()}
        changed = True
        while changed:
            changed = False
            items = list(term_sets)
            for i, left in enumerate(items):
                for right in items[i + 1:]:
                    merged = cls.merge_complement_terms(left, right)
                    if merged is None:
                        continue
                    term_sets.discard(left)
                    term_sets.discard(right)
                    term_sets.add(merged)
                    changed = True
                    break
                if changed:
                    break
            if changed:
                continue
            reduced = cls.reduce_complement_absorption(term_sets)
            if reduced != term_sets:
                term_sets = reduced
                changed = True
        if frozenset() in term_sets:
            return []
        rendered = [" && ".join(sorted(term, key=str)) for term in term_sets]
        return sorted([item for item in rendered if item], key=lambda item: (item.count(" && "), item))

    @staticmethod
    def split_conjunction(term: str) -> list[str]:
        return [part.strip() for part in str(term).split(" && ") if part.strip()]

    @classmethod
    def merge_complement_terms(cls, left: frozenset[str], right: frozenset[str]) -> frozenset[str] | None:
        only_left = left - right
        only_right = right - left
        if len(only_left) != 1 or len(only_right) != 1:
            return None
        left_lit = next(iter(only_left))
        right_lit = next(iter(only_right))
        if cls.negates(left_lit, right_lit):
            return frozenset(left & right)
        return None

    @classmethod
    def reduce_complement_absorption(cls, term_sets: set[frozenset[str]]) -> set[frozenset[str]]:
        """Apply exact boolean absorption on DNF terms.

        Example:
            A || (!A && B)  -> A || B

        The pass only removes one explicit complement literal when the remaining
        literals are already covered by the opposite term. It does not try to
        prove semantic equivalence between arbitrary expressions.
        """

        out = set(term_sets)
        for left in list(term_sets):
            for right in list(term_sets):
                if left == right:
                    continue
                replacement = cls.absorb_complement_term(left, right)
                if replacement is None or replacement == right:
                    continue
                out.discard(right)
                out.add(replacement)
                return cls.simplify_condition_terms(list(out))
        return out

    @classmethod
    def absorb_complement_term(cls, left: frozenset[str], right: frozenset[str]) -> frozenset[str] | None:
        for atom in left:
            negated = cls.negated_condition_atom(atom)
            if negated not in right:
                continue
            left_rest = set(left) - {atom}
            right_rest = set(right) - {negated}
            if left_rest.issubset(right_rest):
                return frozenset(right_rest)
        return None

    @classmethod
    def negates(cls, left: str, right: str) -> bool:
        return cls.negated_inner(left) == right or cls.negated_inner(right) == left

    @staticmethod
    def negated_inner(text: str) -> str | None:
        value = str(text).strip()
        if value.startswith("!(") and value.endswith(")"):
            return value[2:-1].strip()
        return None

    @staticmethod
    def is_loop_scaffold(stmt: SourceStatement) -> bool:
        text = stmt.text.strip()
        node_type = stmt.origin.get("nodeType") if isinstance(stmt.origin, dict) else None
        return text == "for" or node_type == "YulForLoop"

    @staticmethod
    def is_branch_scaffold(stmt: SourceStatement) -> bool:
        text = stmt.text.strip()
        node_type = stmt.origin.get("nodeType") if isinstance(stmt.origin, dict) else None
        return text.startswith("if ") or node_type == "YulIf"

    @classmethod
    def is_control_scaffold(cls, stmt: SourceStatement) -> bool:
        return cls.is_loop_scaffold(stmt) or cls.is_branch_scaffold(stmt)

    @staticmethod
    def raw_statement_line(stmt: SourceStatement) -> str:
        text = stmt.text.strip()
        if text in {"break", "continue", "leave"}:
            return f"{text};"
        return text

    def _loop_groups(self) -> dict[str, dict[str, Any]]:
        blocks = self.fn.control.get("blocks", []) if isinstance(self.fn.control, dict) else []
        edges = self.fn.control.get("edges", []) if isinstance(self.fn.control, dict) else []
        block_by_id = {block.get("block_id"): block for block in blocks}
        out_edges: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for edge in edges:
            out_edges[edge.get("from")].append(edge)

        stmt_by_id = {stmt.stmt_id: stmt for stmt in self.fn.source_statements if stmt.lang == "yul"}
        stmt_order = {stmt.stmt_id: index for index, stmt in enumerate(stmt_by_id.values())}
        groups: dict[str, dict[str, Any]] = {}

        for block in blocks:
            terminator = block.get("terminator") or {}
            attrs = block.get("attrs") or {}
            if terminator.get("node_kind") != "loop-condition":
                continue
            loop_stmt_ids = [stmt_id for stmt_id in block.get("stmts") or [] if stmt_id in stmt_by_id]
            if not loop_stmt_ids:
                continue
            loop_stmt_id = loop_stmt_ids[0]
            condition = self.loop_condition(block, out_edges)
            if not condition:
                continue
            loop_range = self.src_range(attrs.get("src"))
            body_blocks = self.loop_body_blocks(block.get("block_id"), out_edges, block_by_id)
            post_blocks = self.loop_post_blocks(block.get("block_id"), out_edges, block_by_id, body_blocks)
            body_stmt_ids = self.stmts_in_blocks(body_blocks, block_by_id, stmt_by_id)
            post_stmt_ids = self.stmts_in_blocks(post_blocks, block_by_id, stmt_by_id)
            body_stmt_ids.difference_update(post_stmt_ids)
            if not body_stmt_ids:
                continue
            pre_stmt_ids = []
            for stmt in stmt_by_id.values():
                if stmt.stmt_id == loop_stmt_id or stmt.stmt_id in body_stmt_ids or stmt.stmt_id in post_stmt_ids:
                    continue
                if loop_range and self.src_inside(stmt.src, loop_range):
                    pre_stmt_ids.append(stmt.stmt_id)
            body_stmt_ids = sorted(body_stmt_ids, key=lambda item: stmt_order.get(item, 10**9))
            post_stmt_ids = sorted(post_stmt_ids, key=lambda item: stmt_order.get(item, 10**9))
            pre_stmt_ids = sorted(pre_stmt_ids, key=lambda item: stmt_order.get(item, 10**9))
            groups[loop_stmt_id] = {
                "loop_stmt_id": loop_stmt_id,
                "condition": condition,
                "loop_range": loop_range,
                "pre_stmt_ids": pre_stmt_ids,
                "body_stmt_ids": body_stmt_ids,
                "post_stmt_ids": post_stmt_ids,
                "body_block_ids": body_blocks,
                "post_block_ids": post_blocks,
                "consumed_stmt_ids": set([loop_stmt_id, *pre_stmt_ids, *body_stmt_ids, *post_stmt_ids]),
            }
        return groups

    def _loop_exit_suppressions_by_stmt(self) -> dict[str, list[str]]:
        """Map after-loop statements to CFG loop-exit predicates.

        Path enumeration records the predicates needed to leave a loop. Those
        predicates are control-edge evidence, not guards owned by the first
        statement after the loop. The Solidity-like projection should therefore
        suppress them while preserving unrelated outer branch predicates.
        """

        out: dict[str, list[str]] = defaultdict(list)
        yul_stmts = [stmt for stmt in self.fn.source_statements if stmt.lang == "yul"]
        if not yul_stmts or not self.loop_groups:
            return out

        for group in self.loop_groups.values():
            loop_range = group.get("loop_range")
            if not loop_range:
                continue
            predicates = self.loop_exit_predicates(group, loop_range)
            if not predicates:
                continue
            for stmt in yul_stmts:
                if stmt.stmt_id in group.get("consumed_stmt_ids", set()):
                    continue
                if not self.stmt_after_loop(stmt, loop_range):
                    continue
                if not self.statement_mentions_predicate(stmt, predicates):
                    continue
                for predicate in predicates:
                    if predicate not in out[stmt.stmt_id]:
                        out[stmt.stmt_id].append(predicate)
        return out

    def loop_exit_predicates(self, group: dict[str, Any], loop_range: tuple[int, int]) -> list[str]:
        predicates: list[str] = []
        condition = str(group.get("condition") or "").strip()
        if condition:
            predicates.append(condition)
            predicates.append(f"!({condition})")

        local_branch_predicates: list[str] = []
        for effect in self.fn.effects:
            if effect.kind != "Branch":
                continue
            refs = [self.stmt_by_id.get(ref) for ref in effect.stmt_refs]
            if not any(stmt and self.src_inside(stmt.src, loop_range) for stmt in refs):
                continue
            branch_condition = str(effect.attrs.get("condition") or "").strip()
            if not branch_condition:
                continue
            local_branch_predicates.append(branch_condition)
            local_branch_predicates.append(f"!({branch_condition})")
        candidate_predicates = [*predicates, *local_branch_predicates]

        for effect in self.fn.effects:
            if effect.kind != "ControlTransfer":
                continue
            op = str(effect.attrs.get("op") or "").strip()
            if op != "break":
                continue
            refs = [self.stmt_by_id.get(ref) for ref in effect.stmt_refs]
            if not any(stmt and self.src_inside(stmt.src, loop_range) for stmt in refs):
                continue
            for state in effect.attrs.get("path_states") or []:
                for part in self.path_parts(str(state)):
                    if not self.is_any_suppressed_predicate(part, candidate_predicates):
                        continue
                    if part not in predicates:
                        predicates.append(part)
        return predicates

    @classmethod
    def is_any_suppressed_predicate(cls, predicate: str, suppress_predicates: list[str]) -> bool:
        return cls.is_suppressed_predicate(predicate, suppress_predicates)

    @classmethod
    def stmt_after_loop(cls, stmt: SourceStatement, loop_range: tuple[int, int]) -> bool:
        rng = cls.src_range(stmt.src)
        return bool(rng and rng[0] >= loop_range[1])

    def statement_mentions_predicate(self, stmt: SourceStatement, predicates: list[str]) -> bool:
        for effect in self.effects_by_ref.get(stmt.stmt_id, []):
            for state in effect.attrs.get("path_states") or []:
                for part in self.path_parts(str(state)):
                    if self.is_suppressed_predicate(part, predicates):
                        return True
        for overlay in self.overlays_by_ref.get(stmt.stmt_id, []):
            for state in overlay.attrs.get("path_states") or []:
                for part in self.path_parts(str(state)):
                    if self.is_suppressed_predicate(part, predicates):
                        return True
            for effect_id in overlay.effects:
                effect = self.effect_by_id.get(effect_id)
                if not effect:
                    continue
                for state in effect.attrs.get("path_states") or []:
                    for part in self.path_parts(str(state)):
                        if self.is_suppressed_predicate(part, predicates):
                            return True
        return False

    @staticmethod
    def loop_condition(block: dict[str, Any], out_edges: dict[str, list[dict[str, Any]]]) -> str | None:
        for edge in out_edges.get(block.get("block_id"), []):
            kind = str(edge.get("kind") or "")
            if kind.startswith("true: "):
                return kind.removeprefix("true: ").strip()
        text = str((block.get("terminator") or {}).get("text") or "")
        if text.startswith("for condition "):
            return text.removeprefix("for condition ").strip()
        return None

    @staticmethod
    def loop_body_blocks(loop_block_id: str, out_edges: dict[str, list[dict[str, Any]]], block_by_id: dict[str, dict[str, Any]]) -> set[str]:
        starts = [
            edge.get("to")
            for edge in out_edges.get(loop_block_id, [])
            if str(edge.get("kind") or "").startswith("true: ")
        ]
        body: set[str] = set()
        stack = [item for item in starts if item]
        while stack:
            block_id = stack.pop()
            if not block_id or block_id in body or block_id == loop_block_id:
                continue
            block = block_by_id.get(block_id)
            if not block:
                continue
            node_kind = (block.get("terminator") or {}).get("node_kind")
            if node_kind in {"loop-merge", "loop-post"}:
                continue
            body.add(block_id)
            for edge in out_edges.get(block_id, []):
                kind = str(edge.get("kind") or "")
                target = edge.get("to")
                if kind == "loop back" or target == loop_block_id:
                    continue
                stack.append(target)
        return body

    @staticmethod
    def loop_post_blocks(loop_block_id: str, out_edges: dict[str, list[dict[str, Any]]], block_by_id: dict[str, dict[str, Any]], body_blocks: set[str]) -> set[str]:
        post_starts = []
        for block_id in body_blocks:
            for edge in out_edges.get(block_id, []):
                target = edge.get("to")
                target_block = block_by_id.get(target)
                if target_block and (target_block.get("terminator") or {}).get("node_kind") == "loop-post":
                    post_starts.append(target)
        out: set[str] = set()
        stack = list(post_starts)
        while stack:
            block_id = stack.pop()
            if not block_id or block_id in out or block_id == loop_block_id:
                continue
            block = block_by_id.get(block_id)
            if not block:
                continue
            node_kind = (block.get("terminator") or {}).get("node_kind")
            if node_kind == "loop-merge":
                continue
            out.add(block_id)
            for edge in out_edges.get(block_id, []):
                target = edge.get("to")
                if target == loop_block_id or str(edge.get("kind") or "") == "loop back":
                    continue
                stack.append(target)
        return out

    @staticmethod
    def stmts_in_blocks(block_ids: set[str], block_by_id: dict[str, dict[str, Any]], stmt_by_id: dict[str, SourceStatement]) -> set[str]:
        out: set[str] = set()
        for block_id in block_ids:
            for stmt_id in block_by_id.get(block_id, {}).get("stmts") or []:
                stmt = stmt_by_id.get(stmt_id)
                if stmt and not SolidityLikeRenderer.is_loop_scaffold(stmt):
                    out.add(stmt_id)
        return out

    @staticmethod
    def src_range(src: Any) -> tuple[int, int] | None:
        parts = str(src or "").split(":")
        if len(parts) < 2:
            return None
        try:
            start = int(parts[0])
            length = int(parts[1])
        except ValueError:
            return None
        return start, start + length

    @classmethod
    def src_inside(cls, src: Any, outer: tuple[int, int]) -> bool:
        inner = cls.src_range(src)
        if not inner:
            return False
        return outer[0] <= inner[0] and inner[1] <= outer[1]

    @staticmethod
    def _effects_by_ref(effects: list[EffectNode]) -> dict[str, list[EffectNode]]:
        out: dict[str, list[EffectNode]] = defaultdict(list)
        for effect in effects:
            for ref in effect.stmt_refs:
                out[ref].append(effect)
        return out

    def _overlays_by_anchor(self, overlays: list[SemanticOverlay]) -> dict[str, list[SemanticOverlay]]:
        out: dict[str, list[SemanticOverlay]] = defaultdict(list)
        for overlay in overlays:
            anchor = self.overlay_anchor(overlay)
            if anchor:
                out[anchor].append(overlay)
        return out

    def overlay_anchor(self, overlay: SemanticOverlay) -> str | None:
        refs = [ref for ref in overlay.stmt_refs if self.is_yul_ref(ref)]
        if not refs:
            return None
        if overlay.kind == "MappingSlot":
            return refs[0]
        return refs[-1]

    @staticmethod
    def _condition_aliases(effects: list[EffectNode]) -> dict[str, str]:
        aliases: dict[str, str] = {}
        for effect in effects:
            if effect.kind != "Branch":
                continue
            condition = str(effect.attrs.get("condition") or "").strip()
            final = str(effect.attrs.get("condition_final_temp") or "").strip()
            if condition and final:
                aliases[condition] = final
                normalized = normalize_expr(condition, context="condition")
                if normalized:
                    aliases[str(normalized)] = final
                    aliases[SolidityLikeRenderer.strip_outer_parens(str(normalized))] = final
        return aliases

    @staticmethod
    def _memory_construction_notes(overlays: list[SemanticOverlay]) -> list[str]:
        notes: list[str] = []
        for overlay in overlays:
            if overlay.kind not in {"StructInitializationFragment", "ReturnMemoryStructConstruction"}:
                continue
            target = overlay.attrs.get("target")
            type_string = overlay.attrs.get("type") or overlay.attrs.get("struct_type")
            reason = overlay.attrs.get("reason")
            notes.append(f"/* struct initialization fragment {target}: {type_string}; {reason} */")
        return notes

    @staticmethod
    def _struct_field_lines_by_effect(overlays: list[SemanticOverlay]) -> dict[str, str]:
        out: dict[str, str] = {}
        for overlay in overlays:
            if overlay.kind == "StructFieldWrite":
                effect_id = overlay.attrs.get("write_effect") or (overlay.effects[0] if overlay.effects else None)
                line = overlay.attrs.get("solidity_like")
                if effect_id and line:
                    out[str(effect_id)] = str(line)
                continue
            if overlay.kind in {"StructMutationFragment", "StructMemoryMutation"}:
                for mutation in overlay.attrs.get("mutations") or []:
                    effect_id = mutation.get("write_effect")
                    line = mutation.get("solidity_like")
                    if effect_id and line:
                        out[str(effect_id)] = str(line)
                continue
            if overlay.kind not in {"StructInitializationFragment", "ReturnMemoryStructConstruction"}:
                continue
            target = overlay.attrs.get("target")
            for binding in overlay.attrs.get("fields") or []:
                field = binding.get("field") or {}
                effect_id = binding.get("write_effect")
                name = field.get("name")
                value = binding.get("value")
                if target and name and effect_id:
                    out[str(effect_id)] = f"{target}.{name} = {normalize_expr(value)};"
        return out

    def is_yul_ref(self, ref: str) -> bool:
        stmt = self.stmt_by_id.get(ref)
        return bool(stmt and stmt.lang == "yul")

    @staticmethod
    def _skip_branch_conditions(overlays: list[SemanticOverlay]) -> set[str]:
        out: set[str] = set()
        for overlay in overlays:
            if overlay.kind != "RequireOverlay":
                continue
            attrs = overlay.attrs
            nearest = attrs.get("nearest_condition")
            if nearest:
                out.add(str(nearest))
            for condition in attrs.get("require_conditions") or []:
                if condition and not str(condition).startswith("!("):
                    out.add(str(condition))
        return out

    def overlay_lines(self, overlays: list[SemanticOverlay]) -> list[str]:
        guarded_expression = self.require_and_expression_lines(overlays)
        if guarded_expression:
            return guarded_expression
        for kind in (
            "PathConditionedEventEmit",
            "PathConditionedCustomErrorRevert",
            "PathConditionedRawReturnData",
            "PathConditionedLowLevelCall",
            "PathConditionedStaticCallOverlay",
            "PathConditionedDelegateCallOverlay",
            "PathConditionedPrecompileOutputRead",
            "PathConditionedPrecompileCall",
            "EventEmit",
            "PrecompileOutputRead",
            "PrecompileCall",
            "RawReturnData",
            "RequireOverlay",
            "CustomErrorRevert",
            "MappingWrite",
            "MappingRead",
            "StateVariableWrite",
            "StateVariableRead",
            "PathConditionedStorageWrite",
            "PathConditionedStorageRead",
            "StoragePointerSlotBinding",
            "CalldataWordRead",
            "AddressHasCode",
            "AddressCodeSize",
            "StructFieldRead",
            "MappingSlot",
        ):
            for overlay in overlays:
                if overlay.kind != kind:
                    continue
                if overlay.kind.startswith("PathConditioned"):
                    lines = self.path_conditioned_lines(overlay)
                    if lines:
                        return lines
                line = self.line_for_overlay(overlay)
                if line:
                    return [line]
        return []

    def require_and_expression_lines(self, overlays: list[SemanticOverlay]) -> list[str]:
        require_lines = [
            line
            for overlay in overlays
            if overlay.kind == "RequireOverlay"
            for line in [self.line_for_overlay(overlay)]
            if line
        ]
        if not require_lines:
            return []
        expression = self.expression_normalization(overlays)
        if not expression:
            return []
        return [*require_lines, expression]

    @staticmethod
    def evaluation_step_lines(overlays: list[SemanticOverlay]) -> list[str]:
        steps = [overlay for overlay in overlays if overlay.kind == "EvaluationStep"]
        steps.sort(key=lambda overlay: int(overlay.attrs.get("order") or 0))
        call_lines_by_result = {
            overlay.attrs.get("result"): overlay.attrs.get("solidity_like")
            for overlay in overlays
            if overlay.kind in {"AbiEncodedLowLevelCall", "LowLevelCall", "StaticCallOverlay", "DelegateCallOverlay"}
            and overlay.attrs.get("result")
            and overlay.attrs.get("solidity_like")
        }
        path_output_lines_by_target = {
            overlay.attrs.get("target"): SolidityLikeRenderer.path_conditioned_lines(overlay)
            for overlay in overlays
            if overlay.kind == "PathConditionedPrecompileOutputRead"
            and overlay.attrs.get("target")
        }
        state_read_lines_by_target = {
            overlay.attrs.get("target"): overlay.attrs.get("solidity_like")
            for overlay in overlays
            if overlay.kind == "StateVariableRead"
            and overlay.attrs.get("target")
            and overlay.attrs.get("solidity_like")
        }
        skip_temps = SolidityLikeRenderer.consumed_evaluation_temps(steps, set(state_read_lines_by_target))
        lines: list[str] = []
        for overlay in steps:
            temp = overlay.attrs.get("temp")
            if temp in skip_temps:
                continue
            path_output_lines = path_output_lines_by_target.get(temp)
            if path_output_lines:
                lines.extend(path_output_lines)
                continue
            line = (
                state_read_lines_by_target.get(temp)
                or call_lines_by_result.get(temp)
                or overlay.attrs.get("solidity_like")
            )
            if line:
                lines.append(line)
        return lines

    @staticmethod
    def consumed_evaluation_temps(steps: list[SemanticOverlay], recovered_state_read_targets: set[Any]) -> set[Any]:
        by_temp = {
            overlay.attrs.get("temp"): overlay
            for overlay in steps
            if overlay.attrs.get("temp")
        }
        uses: dict[Any, list[SemanticOverlay]] = defaultdict(list)
        for overlay in steps:
            for arg in overlay.attrs.get("evaluated_args") or []:
                if arg in by_temp:
                    uses[arg].append(overlay)
        skip: set[Any] = set()
        for overlay in steps:
            if overlay.attrs.get("temp") not in recovered_state_read_targets:
                continue
            for arg in overlay.attrs.get("evaluated_args") or []:
                producer = by_temp.get(arg)
                if not producer:
                    continue
                if producer.attrs.get("call") not in {"keccak256", "not"}:
                    continue
                if uses.get(arg) == [overlay]:
                    skip.add(arg)
        return skip

    def line_for_overlay(self, overlay: SemanticOverlay) -> str | None:
        attrs = overlay.attrs
        if overlay.kind == "RequireOverlay":
            if attrs.get("elided_by_native_precompile"):
                return None
            return attrs.get("require_like")
        if overlay.kind == "EventEmit":
            return attrs.get("emit_like")
        if overlay.kind == "CustomErrorRevert":
            return attrs.get("revert_like") or (f"revert {attrs.get('error')};" if attrs.get("error") else None)
        if overlay.kind in {"PrecompileCall", "PrecompileOutputRead"}:
            return attrs.get("solidity_like")
        if overlay.kind == "RawReturnData":
            return attrs.get("solidity_like")
        if overlay.kind in {"MappingRead", "MappingWrite", "StateVariableRead", "StateVariableWrite"}:
            if overlay.kind in {"MappingRead", "StateVariableRead"} and attrs.get("nested_in_memory_value") and not attrs.get("target"):
                return None
            line = attrs.get("solidity_like")
            if line and not line.replace(" ", "").endswith("=;"):
                return line
            return None
        if overlay.kind in {"PathConditionedStorageRead", "PathConditionedStorageWrite"}:
            return self.path_conditioned_line(overlay)
        if overlay.kind.startswith("PathConditioned"):
            return self.path_conditioned_line(overlay)
        if overlay.kind == "StoragePointerSlotBinding":
            return attrs.get("solidity_like")
        if overlay.kind == "CalldataWordRead":
            return attrs.get("solidity_like")
        if overlay.kind in {"AddressHasCode", "AddressCodeSize"}:
            return attrs.get("solidity_like")
        if overlay.kind == "StructFieldRead":
            return attrs.get("solidity_like")
        if overlay.kind == "MappingSlot":
            target = attrs.get("target")
            expr = attrs.get("expression")
            if target and expr:
                return f"{target} = slot({expr});"
        return None

    @staticmethod
    def path_conditioned_line(overlay: SemanticOverlay) -> str | None:
        lines = SolidityLikeRenderer.path_conditioned_lines(overlay)
        if lines:
            return " ".join(lines)
        return None

    @classmethod
    def path_conditioned_lines(cls, overlay: SemanticOverlay) -> list[str]:
        candidates = overlay.attrs.get("candidates") or []
        grouped: dict[str, list[str | None]] = {}
        line_order: list[str] = []
        seen: set[tuple[str, str]] = set()
        for candidate in candidates:
            line = candidate.get("solidity_like")
            condition = candidate.get("condition")
            key = (str(condition or ""), str(line or ""))
            if candidate.get("status") != "resolved" or not line or key in seen:
                continue
            line_text = str(line)
            if line_text not in grouped:
                grouped[line_text] = []
                line_order.append(line_text)
            grouped[line_text].append(str(condition) if condition else None)
            seen.add(key)

        out: list[str] = []
        for line in line_order:
            conditions = grouped[line]
            rendered_conditions = cls.simplify_candidate_conditions(conditions)
            if not rendered_conditions:
                out.append(line)
                continue
            if len(rendered_conditions) == 1:
                out.extend(cls.render_conditioned_lines(rendered_conditions[0], [line]))
            else:
                condition = " || ".join(f"({item})" for item in rendered_conditions)
                out.extend(cls.render_conditioned_lines(condition, [line]))
        return out

    @classmethod
    def simplify_candidate_conditions(cls, conditions: list[str | None]) -> list[str]:
        """Collapse equivalent path conditions for identical rendered semantics.

        This is a display-only optimization. It is intentionally limited to
        candidates with the same `solidity_like` text, so it can simplify
        `A && B` plus `!A && B` into `B` without merging distinct effects.
        """

        if any(condition is None or str(condition).strip() in {"", "entry"} for condition in conditions):
            return []
        raw = [
            str(condition)
            for condition in conditions
            if str(condition).strip()
        ]
        if not raw:
            return []
        simplified = cls.simplify_disjunction(raw)
        return simplified

    @classmethod
    def render_conditioned_lines(cls, condition: str, lines: list[str]) -> list[str]:
        normalized = normalize_expr(condition, context="condition")
        tree_lines = cls.condition_tree_block(normalized, lines)
        if tree_lines:
            return tree_lines
        return [f"if ({normalized}) {{", *(f"    {line}" for line in lines), "}"]

    @staticmethod
    def expression_normalization(overlays: list[SemanticOverlay]) -> str | None:
        for overlay in overlays:
            if overlay.kind == "ExpressionNormalization":
                return overlay.attrs.get("solidity_like")
        return None

    @staticmethod
    def value_expression_normalization(overlays: list[SemanticOverlay]) -> str | None:
        for overlay in overlays:
            if overlay.kind == "ExpressionNormalization" and overlay.attrs.get("context") == "value":
                return overlay.attrs.get("solidity_like")
        return None

    def branch_effect(self, stmt: SourceStatement) -> EffectNode | None:
        for effect in self.effects_by_ref.get(stmt.stmt_id, []):
            if effect.kind == "Branch":
                return effect
        return None

    def memory_write_line(self, stmt: SourceStatement) -> str | None:
        for effect in self.effects_by_ref.get(stmt.stmt_id, []):
            if effect.kind != "MemoryWrite":
                continue
            if effect.effect_id in self.struct_field_lines_by_effect:
                return self.struct_field_lines_by_effect[effect.effect_id]
            if effect.attrs.get("write_kind") in {"loop_phi"}:
                continue
            address = self.memory_address(effect.attrs)
            value = self.memory_value(effect.attrs.get("value"))
            if not address:
                continue
            return f"memory[{address}] = {value};"
        return None

    @staticmethod
    def memory_value(value: Any) -> str:
        text = str(value or "").strip()
        m = re.match(r"^sload\(([A-Za-z_$][A-Za-z0-9_$]*)\.slot\)$", text)
        if m:
            return m.group(1)
        return normalize_expr(value)

    @staticmethod
    def memory_address(attrs: dict[str, Any]) -> str | None:
        aliases = attrs.get("aliases") or []
        if aliases:
            alias = aliases[0]
            base = alias.get("base")
            offset = alias.get("offset")
            if base is not None and offset is not None:
                try:
                    offset_i = int(offset)
                except Exception:
                    offset_i = None
                if offset_i == 0:
                    return str(base)
                if offset_i is not None:
                    return f"{base} + {offset_i}"
            expr = alias.get("expression")
            if expr:
                return normalize_expr(expr)
        address = attrs.get("address")
        return normalize_expr(address) if address else None
